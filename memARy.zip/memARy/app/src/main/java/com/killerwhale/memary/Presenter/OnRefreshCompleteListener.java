package com.killerwhale.memary.Presenter;

public interface OnRefreshCompleteListener {
    void stopRefresh();
}
