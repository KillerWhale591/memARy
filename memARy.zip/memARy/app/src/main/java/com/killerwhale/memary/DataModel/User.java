package com.killerwhale.memary.DataModel;

/**
 * User model
 * @author Zeyu Fu
 */
public class User {
    public static final String FIELD_USERNAME = "username";
    public static final String FIELD_AVATAR = "avatar";
    public static final String FIELD_POSTS = "posts";
}
