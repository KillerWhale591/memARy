package com.killerwhale.memary.Presenter;

/**
 * The presenter of AR Activity
 * Author: Qili Zeng
 **/

public class ARPresenter {
    public static final int MODE_VIEW = 0;
    public static final int MODE_DRAW = 1;





}
